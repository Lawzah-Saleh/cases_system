<template>
  <h1>Statistics Page</h1>
</template>
