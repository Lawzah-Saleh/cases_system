<template>
  <h1>Team Page</h1>
</template>
