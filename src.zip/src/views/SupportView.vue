<template>
  <h1>Supports Page</h1>
</template>