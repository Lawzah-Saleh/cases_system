<template>
  <router-view />
</template>

<style>
html, body {
  margin: 0;
  padding: 0;
  background: #f5f7fb;
  font-family: Inter, sans-serif;
  height: 100%;
}
</style>
